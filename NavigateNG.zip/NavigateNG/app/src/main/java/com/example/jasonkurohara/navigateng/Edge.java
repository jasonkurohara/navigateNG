package com.example.jasonkurohara.navigateng;

import java.util.ArrayList;

public class Edge {

    private Vertex start;
    private Vertex end;

    public void setStart(Vertex a){
        start = a;
    }

    public void setEnd(Vertex a){
        end = a;
    }

    public ArrayList<Vertex> getConnections(){
        ArrayList<Vertex> connections = new ArrayList<Vertex>();
        connections.add(start);
        connections.add(end);
        return connections;
    }
}
