package com.example.jasonkurohara.navigateng;

import android.os.health.PackageHealthStats;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.chrisbanes.photoview.PhotoView;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class NavigateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigate);

        PhotoView map = (PhotoView) findViewById(R.id.photo_view);
        map.setImageResource(R.drawable.map);
    }
}


public void readText(){

    String data = "";
    StringBuffer sbuffer = new StringBuffer();
    InputStream is = this.getResources().openRawResource(R.raw.sample);
    BufferedReader reader = new BufferedReader(new InputStreamReader(is));

    if( is != null){

        try{
            while((data=reader.readLine()) != null){
                sbuffer.append(data + "n");
            }
            is.close();
        } catch(Exception e){
            e.printStackTrace();
        }
    }


}