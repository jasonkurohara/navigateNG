package com.example.jasonkurohara.navigateng;

import java.util.ArrayList;

public class Vertex extends Graph{
    public int x;
    public int y;

    private ArrayList<Vertex> neighbors;


    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }

    public boolean isConnected(  Vertex end ){


        for( Edge currentEdge: allEdges ){
            ArrayList<Vertex> connections = new ArrayList<Vertex>();
            connections = currentEdge.getConnections();
            if( connections.contains(this) && connections.contains(end) ){
                return true;
            }
        }
        return false;
    }
}
